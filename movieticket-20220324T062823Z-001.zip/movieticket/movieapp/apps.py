from django.apps import AppConfig


class MovieappConfig(AppConfig):
    name = 'movieapp'
